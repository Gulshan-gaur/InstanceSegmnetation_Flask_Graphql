class Devconfig():
    """MONGODB_SETTINGS = {
        'db': Config.SERVICE_NAME,
        'host': 'mongomock://localhost'
    }"""

    JWT_SECRET_KEY = "loginregister"
